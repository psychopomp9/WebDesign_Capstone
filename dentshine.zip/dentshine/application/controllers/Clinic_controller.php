<?php

class Clinic_controller extends CI_Controller
{
    public function index()
    {
        if (isset($_SESSION['user_id'])) {
            // $data['doctor_data']=$this->doctor_model->doctorlist();

            $this->load->view('admin/index');
        } else {
            redirect('Client_controller/login');
        }
    }
    public function login()
    {
        $this->load->view('admin/login');

    }
    public function user_auth()
    {
        $user_email = $this->input->post('user_email');
        $user_password = $this->input->post('user_password');

        $res = $this->user_model->user_auth($user_email, $user_password);

        if ($res != null) {

            $_SESSION['user_email'] = $res['user_email'];
            $_SESSION['user_password'] = $res['user_password'];
            $_SESSION['user_type'] = $res['user_type'];
            $_SESSION['user_id'] = $res['user_id_fk'];
            if ($res['user_type'] == 'patient') {

                redirect('Client_controller/index');
            } else {
                redirect('Clinic_controller/index');
            }
        } else {

            $data['invalid'] = "invalid user email and password";
            $this->load->view('admin/login');
        }

    }
    public function logout()
    {
        unset($_SESSION['user_id']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_password']);
        unset($_SESSION['user_type']);

        redirect('Client_controller/login');

    }
    public function forgetpassword()
    {
        $this->load->view('admin/forgotpassword');
    }
    public function forgetpass()
    {
        $this->load->view('admin/forgetpass');
    }
    public function checkemail()
    {
        $user_email = $this->input->post('user_email');
        $res = $this->user_model->user_pass($user_email);
        if ($res != null) {
            $data['user_data'] = $res;

            $this->load->view('admin/forgetpass', $data);
        } else {
            $data['invalid'] = "invalid email address";
            $this->load->view('admin/forgotpassword', $data);
        }
    }
    public function updatepassword()
    {
        $user_password = $this->input->post('user_password');
        $user_cpass = $this->input->post('user_cpass');

        if ($user_password != $user_cpass) {
            $data['invalid'] = "password does't match";
            $this->load->view('admin/forgetpass', $data);
        } else {
            $data['user_id_pk'] = $this->input->post('user_id_pk');
            $data['user_password'] = $this->input->post('user_password');

            $this->user_model->updatedpass($data);
            redirect('Clinic_controller/login');

        }
    }

    //appointment
    public function addappointment()
    {
        $data['treatment_data'] = $this->treatment_model->treatmentlist();
        $this->load->view('admin/addappointment', $data);
    }

    public function showappointment()
    {
        $data['doctor_data'] = $this->doctor_model->doctorlist();
        $data['appointment_data'] = $this->appointment_model->appointmentlist();
        $this->load->view('admin/showappointment', $data);

    }
    public function editappointment($id)
    {
        $data['treatment_data'] = $this->treatment_model->treatmentlist();
        $data['appointment_data'] = $this->appointment_model->appointmentdata($id);
        $this->load->view('admin/addappointment', $data);
    }
    public function updateappointment()
    {
        $data['ap_id_pk'] = $this->input->post('ap_id_pk');
        $data['patient_id_fk'] = $this->input->post('patient_name');
        $data['ap_type'] = $this->input->post('ap_type');
        $data['treatment_id_fk'] = $this->input->post('treatment_name');
        $data['email'] = $this->input->post('email');
        $data['age'] = $this->input->post('age');
        $data['date'] = $this->input->post('date');
        $data['mobile_no'] = $this->input->post('mobile_no');
        $data['reason'] = $this->input->post('reason');

        $this->appointment_model->updateappointment($data);

        redirect('Clinic_controller/showappointment');
    }
    public function deleteappointment($id)
    {

        $this->appointment_model->deleteappointment($id);
        redirect('Clinic_controller/showappointment');
    }

    // book appointment
    public function addbookappointment()
    {
        $data['doctor_data'] = $this->doctor_model->doctorlist();
        $data['treatment_data'] = $this->treatment_model->treatmentlist();
        $data['patient_data'] = $this->patient_model->patientlist();
        $this->load->view('admin/addbookappointment', $data);
    }
    public function insertbookappointment($id)
    {

        $appointment_data = $this->appointment_model->appointmentdata($id);

        $patient_name = explode('(', rtrim($this->input->post('patient_name'), ')'));
        if (count($patient_name) == 2) {
            $case_id = $patient_name[1];
        }
        $data1['patient_name'] = $patient_name[0];
        $data1['email_id'] = $this->input->post('email');
        $data1['age'] = $this->input->post('age');
        $data1['mobile_no'] = $this->input->post('mobile_no');
        $data1['case_id'] = "CASE-" . rand(1, 999);
        $patient_data = $this->patient_model->patient_check($data1);

        if ($patient_data != null) {
            $data['patient_id_fk'] = $patient_data['patient_id_pk'];
        } else {
            $data['patient_id_fk'] = $this->patient_model->insertpatient($data1);

            $da['user_id_fk'] = $data['patient_id_fk'];
            $da['user_email'] = $data1['email_id'];
            $da['user_password'] = $data1['mobile_no'];
            $da['user_type'] = 'patient';

            $this->user_model->insertuser($da);

        }

        $data['treatment_id_fk'] = $appointment_data['treatment_id_fk'];
        $data['doctor_id_fk'] = $this->input->post('doctor_name');
        $data['date'] = $appointment_data['date'];
        $data['time'] = $this->input->post('time');
        $data['reason'] = $appointment_data['reason'];
        $bid = $this->appointment_book_model->insertbookappointment($data);

        $data2['ap_id_pk'] = $id;
        $data2['is_read'] = 0;
        $this->appointment_model->updateappointment($data2);
        $bookappointment_data = $this->appointment_book_model->bookappointmentdata($bid);

        $msg = '<h1>Your Appoitment is confirm.</h1>';

        $msg .= '<b>Time : </b>' . $bookappointment_data['time'] . '<br>';
        $msg .= '<b>Assign doctor : </b>' . $bookappointment_data['doctor_name'] . '<br>';
        $msg .= '<b>Date : </b>' . $bookappointment_data['date'];

        $this->email->to($appointment_data['email']);
        $this->email->from('rahul7654.chaudhari@gmail.com', 'Dentshine');
        $this->email->subject('for Confirm Appointment');
        $this->email->message($msg);
        $this->email->send();

        redirect('Clinic_controller/showbookappointment');
    }
    public function showbookappointment()
    {
        if ($_SESSION['user_type'] == 'doctor') {
            $data['bappointment_data'] = $this->appointment_book_model->bookappointmentdoctorlist($_SESSION['user_id']);
        } else {
            $data['bappointment_data'] = $this->appointment_book_model->bookappointmentlist();
        }

        $this->load->view('admin/showbookappointment', $data);

    }
    public function editbookappointment($id)
    {
        $data['doctor_data'] = $this->doctor_model->doctorlist();
        $data['treatment_data'] = $this->treatment_model->treatmentlist();
        $data['patient_data'] = $this->patient_model->patientlist();
        $data['appointment_data'] = $this->appointment_book_model->bookappointmentdata($id);
        $this->load->view('admin/addbookappointment', $data);
    }
    public function updatebookappointment()
    {
        $data['ap_book_id_pk'] = $this->input->post('ap_book_id_pk');
        $data['patient_id_fk'] = $this->input->post('patient_name');
        $data['treatment_id_fk'] = $this->input->post('treatment_name');
        $data['doctor_id_fk'] = $this->input->post('doctor_name');
        $data['date'] = $this->input->post('date');
        $data['time'] = $this->input->post('time');
        $data['reason'] = $this->input->post('reason');

        $this->appointment_book_model->updatebookappointment($data);

        redirect('Clinic_controller/showbookappointment');
    }
    public function deletebookappointment($id)
    {

        $this->appointment_book_model->deletebookappointment($id);
        redirect('Clinic_controller/showbookappointment');
    }



}

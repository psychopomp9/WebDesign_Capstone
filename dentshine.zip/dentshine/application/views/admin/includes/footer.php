<div class="page-footer">
			
			
		</div>
		<!-- end footer -->
	</div>
	<!-- start js include path -->
	<script src="<?= ASSETS_PATH?>assets/bundles/jquery/jquery.min.js"></script>
	<script src="<?= ASSETS_PATH?>assets/bundles/popper/popper.js"></script>
	<script src="<?= ASSETS_PATH?>assets/bundles/jquery-blockUI/jquery.blockui.min.js"></script>
	<script src="<?= ASSETS_PATH?>assets/bundles/jquery.slimscroll/jquery.slimscroll.js"></script>
	<!-- bootstrap -->
	<script src="<?= ASSETS_PATH?>assets/bundles/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?= ASSETS_PATH?>assets/bundles/bootstrap-switch/js/bootstrap-switch.min.js"></script>
	<!-- data tables -->
	<script src="<?= ASSETS_PATH?>assets/bundles/datatables/jquery.dataTables.min.js"></script>
	<script src="<?= ASSETS_PATH?>assets/bundles/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js"></script>
	<script src="<?= ASSETS_PATH?>assets/data/table-data.js"></script>
	<!-- counterup -->
	<script src="<?= ASSETS_PATH?>assets/bundles/counterup/jquery.waypoints.min.js"></script>
	<script src="<?= ASSETS_PATH?>assets/bundles/counterup/jquery.counterup.min.js"></script>
	<!-- Common js-->
	<script src="<?= ASSETS_PATH?>assets/app.js"></script>
	<script src="<?= ASSETS_PATH?>assets/layout.js"></script>
	<script src="<?= ASSETS_PATH?>assets/theme-color.js"></script>
	<!-- material -->
	<script src="<?= ASSETS_PATH?>assets/bundles/material/material.min.js"></script>
	<!-- chart js -->
	<script src="<?= ASSETS_PATH?>assets/bundles/chart-js/Chart.bundle.js"></script>
	<script src="<?= ASSETS_PATH?>assets/bundles/chart-js/utils.js"></script>
	<script src="<?= ASSETS_PATH?>assets/data/home1-chartjs-data.js"></script>
	<!-- end js include path -->
</body>


<!-- Mirrored from radixtouch.in/templates/admin/redstar/source/light/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 11 Apr 2021 12:58:28 GMT -->
</html>